import hashlib, json, subprocess, zipfile
from pathlib import Path

ZIP_NAME = "Doxa_30_1_Atualizacao.zip"
def apply(root, archive, publish=True):
    root=Path(root).resolve()
    def run(*args): return subprocess.run(args,cwd=root,check=True)
    if not (root/".git").exists(): raise SystemExit("Abra o terminal na pasta Doxa.")
    branch=subprocess.check_output(["git","branch","--show-current"],cwd=root,text=True).strip()
    if branch!="main": raise SystemExit("Abra a branch main antes de aplicar.")
    staged=subprocess.check_output(["git","diff","--cached","--name-only"],cwd=root,text=True).strip()
    if staged: raise SystemExit("Existem alteracoes preparadas para outro commit. Preserve-as antes de continuar.")
    if publish: run("git","pull","--ff-only")
    digest=lambda b:hashlib.sha256(b).hexdigest()
    with zipfile.ZipFile(archive) as z:
        plan=json.loads(z.read("update.json"))
        for name,expected in plan["guards"].items():
            if digest((root/name).read_bytes())!=expected:
                raise SystemExit("Arquivo de base mudou: "+name+". Nenhum arquivo foi substituido.")
        writes=[]
        for e in plan["files"]:
            name=e["path"]; target=root/name
            if not target.resolve().is_relative_to(root): raise SystemExit("Caminho invalido.")
            data=z.read("payload/"+name)
            if digest(data)!=e["after"]: raise SystemExit("ZIP incompleto: "+name)
            current=digest(target.read_bytes()) if target.exists() else None
            if current not in (e["before"],e["after"]):
                raise SystemExit("Alteracao local encontrada: "+name+". Nenhum arquivo foi substituido.")
            if current!=e["after"]: writes.append((target,data))
        for target,data in writes:
            target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(data)
    run("bash","tools/check.sh")
    if publish:
        names=[e["path"] for e in plan["files"]]
        run("git","add","--",*names)
        if subprocess.run(["git","diff","--cached","--quiet"],cwd=root).returncode:
            run("git","commit","-m","Separa leitor V29 e migra bancos locais preservando dados")
        run("git","push","origin","main")
        print("Atualizacao enviada. Abra Actions > APK Android e aguarde a compilacao.")
    else: print("Pacote aplicado e verificado localmente.")

if __name__=="__main__": apply(Path.cwd(), Path.cwd()/ZIP_NAME)
